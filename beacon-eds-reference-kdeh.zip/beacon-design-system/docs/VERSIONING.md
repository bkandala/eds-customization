# Versioning policy

The design system follows [Semantic Versioning](https://semver.org). Consumers are Edge Delivery
sites that pin an exact version, so a version number tells a site owner how much review an
update needs.

## What is public API

Everything listed in `dist/api.json`:

- **tokens**: every `--s2-*` custom property in `tokens.css`
- **variables**: every custom property on `:root` in `foundation.css` (`--color-accent`, `--spacing-l`, …)
- **classes**: class names styled by `foundation.css` (`.btn`, `.btn-accent`, `.btn-outline`, …)
- **icons**: file names in `icons/` (`:heart:` in a document resolves to `heart.svg`)
- **fonts**: file names in `fonts/`

Component-local variables such as `--btn-bg` are not public API. Blocks must not depend on them.

## Which release a change needs

| Change | Release | Why |
|---|---|---|
| Remove or rename a token, variable, class, icon or font | **major** | Sites that use it break: an unset `var()` falls back silently, and a missing icon renders nothing |
| Change a token's role (e.g. `--color-accent` stops being the brand color) | **major** | No name disappears, but every consumer's meaning changes. `api-diff` cannot see this, so declare it with `!` |
| Add a token, variable, class, icon or font | **minor** | Nothing existing changes |
| Change a value (a color step, a radius, an icon drawing) | **patch** | Same names, different look. Consumers' visual diff gate decides if it's small enough to auto-merge |
| Docs, build, CI, tests | none | `dist/` unchanged |

`scripts/api-diff.mjs` computes the required release from `api.json` and blocks PRs whose
Conventional Commit title declares less. It cannot spot a role change or a large visual change
hidden in a patch. Reviewers catch the first. The consumer's visual-diff threshold on
`semver:patch` PRs catches the second.

## Deprecating before removing

To rename without breaking anyone right away:

1. **minor**: add the new name, keep the old one as an alias, and note it in the changelog:
   `--color-subdued: var(--color-text-subdued); /* deprecated: remove in 3.0 */`
2. Consumers migrate at their own pace. `ds:impact` in each site lists the names it uses.
3. **major**: remove the alias.

## How consumers take updates

| Release | Consumer PR | Default merge |
|---|---|---|
| patch | `ds-vX-Y-Z` branch, CI, visual diff gated at 0.5% of pixels per page | auto-merge when green (`DS_AUTOMERGE=patch`) |
| minor | same, visual diff reported, not gated | human review (or `DS_AUTOMERGE=minor`) |
| major | same, plus the impact report lists removed names the site uses | always human review |
