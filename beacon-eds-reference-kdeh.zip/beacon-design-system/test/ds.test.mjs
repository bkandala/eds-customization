import { test } from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { readFileSync, readdirSync } from 'node:fs';
import { diff, declared } from '../scripts/api-diff.mjs';

const read = (p) => readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');

test('committed dist/ matches src/', () => {
  execFileSync('node', ['scripts/build.mjs', '--check'], { stdio: 'pipe' });
});

test('every var(--x) used in dist resolves to a definition in dist', () => {
  const css = read('dist/tokens.css') + read('dist/foundation.css');
  const defined = new Set([...css.matchAll(/(--[a-z0-9-]+)\s*:/g)].map((m) => m[1]));
  const used = new Set([...css.matchAll(/var\((--[a-z0-9-]+)/g)].map((m) => m[1]));
  assert.deepEqual([...used].filter((v) => !defined.has(v)), []);
});

test('icons are referenceable and recolorable', () => {
  for (const f of readdirSync(new URL('../dist/icons', import.meta.url))) {
    const svg = read(`dist/icons/${f}`);
    assert.match(svg, /id="icon"/, `${f} needs id="icon"`);
    assert.doesNotMatch(svg, /fill="#|fill="rgb/, `${f} has a hard-coded fill`);
  }
});

test('font files referenced by foundation.css ship', () => {
  const fonts = readdirSync(new URL('../dist/fonts', import.meta.url));
  for (const [, file] of read('dist/foundation.css').matchAll(/url\("fonts\/([^"]+)"\)/g)) {
    assert.ok(fonts.includes(file), `${file} missing`);
  }
});

test('api diff: removed is major, added minor, changed patch', () => {
  const base = { tokens: { '--a': '1', '--b': '2' }, icons: ['x'] };
  assert.equal(diff(base, base).required, 'none');
  assert.equal(diff(base, { ...base, tokens: { '--a': '1', '--b': '3' } }).required, 'patch');
  assert.equal(diff(base, { ...base, icons: ['x', 'y'] }).required, 'minor');
  assert.equal(diff(base, { ...base, tokens: { '--a': '1' } }).required, 'major');
});

test('Conventional Commit titles map to bumps', () => {
  assert.equal(declared('fix: darker focus ring'), 'patch');
  assert.equal(declared('feat(icons): add pill icon'), 'minor');
  assert.equal(declared('feat!: rename --color-brand'), 'major');
  assert.equal(declared('docs: typo'), 'none');
  assert.equal(declared('update stuff'), null);
});
