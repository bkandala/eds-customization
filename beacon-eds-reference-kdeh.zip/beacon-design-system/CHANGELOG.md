# Changelog

## 2.0.0 (2026-10-31)

* feat!: rename --color-subdued to --color-text-subdued

## 1.1.0 (2026-10-31)

* feat: add --color-positive, --color-negative and the star icon

## 1.0.1 (2026-10-31)

* fix: stronger borders on cards, dividers and the header

## 1.0.0 (2026-10-31)

### Added

* Spectrum 2 tokens from `@adobe/spectrum-tokens` 15.6.0 as `--s2-*`, accent re-pointed to indigo
* Foundation: public `--color-*`, `--spacing-*`, `--radius-*`, `--heading-*`, `--body-*` variables; base type; Spectrum 2 buttons for Author Kit `.btn-*` classes
* Source Sans 3 (OFL) as the open source stand-in for Adobe Clean
* 20 Spectrum 2 workflow icons plus the BEACON mark
