#!/usr/bin/env node
/* Builds dist/ — the only folder consumers receive.
 *
 *   npm run build           write dist/
 *   npm run build -- --check   fail if the committed dist/ is stale (CI)
 *
 * dist/
 *   tokens.css       Spectrum 2 tokens as --s2-* custom properties (generated)
 *   foundation.css   public variables, base element styles, button classes (from src/)
 *   fonts/           Source Sans 3 (OFL)
 *   icons/           SVG icons, each with id="icon" and currentColor
 *   api.json         the public surface, used to decide major / minor / patch
 *
 * dist/ carries no version number on purpose: the version lives in package.json and the git tag,
 * so release commits only touch package.json and CHANGELOG.md.
 */
import {
  cpSync, existsSync, mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync,
} from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';
import buildTokens from './tokens.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const check = process.argv.includes('--check');

function vars(css) {
  const out = {};
  for (const [, name, value] of css.matchAll(/^\s*(--[a-z0-9-]+):\s*([^;]+);/gm)) out[name] = value.trim();
  return out;
}

function classes(css) {
  const noComments = css.replace(/\/\*[\s\S]*?\*\//g, '');
  return [...new Set([...noComments.matchAll(/\.([a-z][a-z0-9-]*)/g)].map((m) => m[1]))]
    .filter((c) => !/^\d/.test(c) && !['woff2', 'svg'].includes(c)).sort();
}

export function build(out) {
  const config = JSON.parse(readFileSync(join(root, 'src/tokens.config.json'), 'utf8'));
  rmSync(out, { recursive: true, force: true });
  cpSync(join(root, 'src/fonts'), join(out, 'fonts'), { recursive: true });
  cpSync(join(root, 'src/icons'), join(out, 'icons'), { recursive: true });
  const tokens = buildTokens(config, root);
  const foundation = readFileSync(join(root, 'src/foundation.css'), 'utf8');
  writeFileSync(join(out, 'tokens.css'), tokens);
  writeFileSync(join(out, 'foundation.css'), foundation);

  const sorted = (o) => Object.fromEntries(Object.entries(o).sort(([a], [b]) => a.localeCompare(b)));
  const api = {
    $comment: 'Public surface of the design system. Removing or renaming anything here is a major release.',
    tokens: sorted(vars(tokens)),
    // Only :root variables are public; component-local ones (--btn-bg) are implementation.
    variables: sorted(vars(foundation.match(/:root\s*{[^}]*}/)[0])),
    classes: classes(foundation),
    icons: readdirSync(join(root, 'src/icons')).filter((f) => f.endsWith('.svg')).map((f) => f.slice(0, -4)).sort(),
    fonts: readdirSync(join(root, 'src/fonts')).filter((f) => f.endsWith('.woff2')).sort(),
  };
  writeFileSync(join(out, 'api.json'), `${JSON.stringify(api, null, 2)}\n`);
  return api;
}

if (check) {
  const tmp = mkdtempSync(join(tmpdir(), 'ds-'));
  build(tmp);
  try {
    execFileSync('diff', ['-r', tmp, join(root, 'dist')], { stdio: 'pipe' });
    console.log('dist/ is up to date.');
  } catch (ex) {
    console.error(`dist/ is stale. Run npm run build and commit dist/.\n${ex.stdout}`);
    process.exit(1);
  } finally {
    rmSync(tmp, { recursive: true, force: true });
  }
} else {
  const api = build(join(root, 'dist'));
  console.log(`Built dist/: ${Object.keys(api.tokens).length} tokens, ${Object.keys(api.variables).length} variables, ${api.classes.length} classes, ${api.icons.length} icons.`);
  if (!existsSync(join(root, 'node_modules'))) console.warn('node_modules missing: run npm ci');
}
