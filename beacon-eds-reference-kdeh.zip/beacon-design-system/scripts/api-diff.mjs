#!/usr/bin/env node
/* Decides what kind of release a change needs by comparing two dist/api.json files.
 *
 *   removed or renamed token / variable / class / icon / font  ->  major
 *   added anything                                             ->  minor
 *   changed a value (a color, a size)                          ->  patch
 *
 * Usage
 *   node scripts/api-diff.mjs --base origin/main            compare git ref to working tree
 *   node scripts/api-diff.mjs old/api.json new/api.json
 *   ... --title "feat!: drop gray-1000"                      also check a Conventional Commit
 *                                                            title declares a big enough bump
 *
 * Writes a markdown report to stdout (and to $GITHUB_STEP_SUMMARY in Actions).
 * Exits 1 when the declared bump is smaller than the required one.
 */
import { appendFileSync, readFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';

const RANK = {
  none: 0, patch: 1, minor: 2, major: 3,
};

export function diff(before, after) {
  const changes = { removed: [], added: [], changed: [] };
  for (const group of ['tokens', 'variables']) {
    const a = before[group] || {};
    const b = after[group] || {};
    for (const k of Object.keys(a)) {
      if (!(k in b)) changes.removed.push(`${group}: ${k}`);
      else if (a[k] !== b[k]) changes.changed.push(`${group}: ${k}: ${a[k]} -> ${b[k]}`);
    }
    for (const k of Object.keys(b)) if (!(k in a)) changes.added.push(`${group}: ${k}`);
  }
  for (const group of ['classes', 'icons', 'fonts']) {
    const a = new Set(before[group] || []);
    const b = new Set(after[group] || []);
    for (const k of a) if (!b.has(k)) changes.removed.push(`${group}: ${k}`);
    for (const k of b) if (!a.has(k)) changes.added.push(`${group}: ${k}`);
  }
  let required = 'none';
  if (changes.changed.length) required = 'patch';
  if (changes.added.length) required = 'minor';
  if (changes.removed.length) required = 'major';
  return { ...changes, required };
}

// Conventional Commits: `feat!:` or a BREAKING CHANGE footer is major, feat minor, fix/perf/style patch.
export function declared(title = '') {
  const m = title.match(/^(\w+)(\([^)]*\))?(!)?:/);
  if (!m) return null;
  if (m[3] || /BREAKING[ -]CHANGE/.test(title)) return 'major';
  if (m[1] === 'feat') return 'minor';
  if (['fix', 'perf', 'style', 'revert'].includes(m[1])) return 'patch';
  return 'none';
}

function load(arg) {
  return JSON.parse(readFileSync(arg, 'utf8'));
}

function fromGit(ref) {
  try {
    return JSON.parse(execFileSync('git', ['show', `${ref}:dist/api.json`], { stdio: 'pipe' }).toString());
  } catch {
    return {};
  }
}

function report(result, title, decl) {
  const list = (name, items) => (items.length ? `\n**${name} (${items.length})**\n${items.slice(0, 50).map((i) => `- \`${i}\``).join('\n')}${items.length > 50 ? '\n- ...' : ''}\n` : '');
  return `### Design system API diff
Required release: **${result.required}**${title ? `  \nPR title: \`${title}\` declares **${decl ?? 'nothing (not a Conventional Commit)'}**` : ''}
${list('Removed: breaking', result.removed)}${list('Added', result.added)}${list('Changed values', result.changed)}`;
}

if (process.argv[1] === new URL(import.meta.url).pathname) {
  const args = process.argv.slice(2);
  const opt = (name) => {
    const i = args.indexOf(name);
    return i >= 0 ? args.splice(i, 2)[1] : undefined;
  };
  const base = opt('--base');
  const title = opt('--title') ?? process.env.PR_TITLE;
  const before = base ? fromGit(base) : load(args[0]);
  const after = base ? load('dist/api.json') : load(args[1]);
  const result = diff(before, after);
  const decl = title ? declared(title) : undefined;
  const md = report(result, title, decl);
  console.log(md);
  if (process.env.GITHUB_STEP_SUMMARY) appendFileSync(process.env.GITHUB_STEP_SUMMARY, md);
  if (title !== undefined && RANK[decl ?? 'none'] < RANK[result.required]) {
    console.error(`\nThis change needs a ${result.required} release but the title declares ${decl ?? 'none'}.`
      + `\nUse ${result.required === 'major' ? '"feat!: ..." or "fix!: ..."' : ''}${result.required === 'minor' ? '"feat: ..."' : ''}${result.required === 'patch' ? '"fix: ..."' : ''}.`);
    process.exit(1);
  }
}
