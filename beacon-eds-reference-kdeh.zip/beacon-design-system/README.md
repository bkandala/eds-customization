# BEACON Design System

Design tokens, foundation CSS, fonts and icons for BEACON's Edge Delivery Services sites, built on
**Adobe Spectrum 2** (`@adobe/spectrum-tokens`, Apache-2.0). It lives in its own repo and ships
as a versioned package. Each site pins one version and moves forward through a reviewed PR.

```
beacon-design-system (this repo)                     beacon-study (EDS site + blocks)
  src/ ──npm run build──▶ dist/  ──tag vX.Y.Z──▶  package.json pins vX.Y.Z
                                   release         npm run ds:update ──▶ styles/ds/, img/icons/
                                   dispatch ─────▶ ds-update workflow opens PR ─▶ CI + visual diff + preview
```

## What's in the package

| `dist/` file | What it is | Consumers load it as |
|---|---|---|
| `tokens.css` | 440+ Spectrum 2 tokens as `--s2-*`, generated | `/styles/ds/tokens.css` |
| `foundation.css` | Public variables (`--color-*`, `--spacing-*`, `--radius-*`, `--heading-*`), base type, Spectrum 2 buttons for Author Kit's `.btn-*` classes, Source Sans 3 `@font-face` | `/styles/ds/foundation.css` |
| `fonts/` | Source Sans 3 (OFL). It stands in for Adobe Clean, which is licensed only for Adobe products | `/styles/ds/fonts/` |
| `icons/` | Spectrum 2 workflow icons and the BEACON mark (`id="icon"`, `currentColor`) | `/img/icons/<name>.svg` |
| `api.json` | The public surface, used for semver decisions | tooling only |

The layers:

```
--s2-indigo-900  →  --s2-accent-color-900  →  --color-accent  →  .btn-accent, blocks
Spectrum primitive   Spectrum semantic         DS public var      consumer CSS
```

Rebrand by changing `brand.accent` in `src/tokens.config.json`. For example, `"seafoam"` repoints
every accent token.

## Working on it

```bash
npm ci
npm run build        # src/ -> dist/ (commit dist/; CI checks it is fresh)
npm test             # dist fresh, every var() resolves, icons valid, semver rules
npm run lint
npm run specimen     # http://localhost:4000/specimen.html shows dist/ without a site
npm run api:diff     # what release your change needs, vs origin/main
```

## Releases (major / minor / patch)

Releases are automated with **release-please** and **Conventional Commit** PR titles (squash merge):

| PR title | Release | Use for |
|---|---|---|
| `fix: …`, `perf: …`, `style: …` | patch | Changed values: a color, a size, an icon drawing |
| `feat: …` | minor | Added a token, variable, class, icon or font |
| `feat!: …`, `fix!: …` | major | Removed or renamed anything in `api.json` |
| `docs:`, `chore:`, `ci:`, `test:` | none | No change to `dist/` |

**CI enforces it.** `scripts/api-diff.mjs` compares `dist/api.json` with the base branch and fails the
PR when the title declares a smaller bump than the change needs. For example, it fails a `feat:` PR
that removes a token. See [docs/VERSIONING.md](docs/VERSIONING.md).

When a PR is merged, release-please updates a release PR (`chore(main): release x.y.z`) with the next
version and `CHANGELOG.md`. Merging that release PR:

1. tags `vX.Y.Z` and publishes a GitHub release with the package tarball attached,
2. sends `design-system-released` to every repo in `consumers.json`,
3. starts each consumer's **ds-update** workflow, which opens a PR moving the site to that version
   and tests it.

## Setup checklist

- [ ] Create `KDEH-KP/beacon-design-system` and push this repo. Make it private if you like.
- [ ] Branch protection on `main`: require the CI check; allow squash merge only, with the PR title as the commit message.
- [ ] Settings → Actions → allow GitHub Actions to create pull requests (release-please needs it).
- [ ] Secret `CONSUMER_DISPATCH_TOKEN`: a fine-grained PAT or GitHub App token with *Contents: read & write* on each consumer repo.
- [ ] List consumer repos in `consumers.json`.

## License

Code: Apache-2.0. Spectrum tokens and icons: Apache-2.0, © Adobe. Source Sans 3: SIL OFL 1.1, © Adobe.
BEACON is a fictional brand for a reference implementation.
