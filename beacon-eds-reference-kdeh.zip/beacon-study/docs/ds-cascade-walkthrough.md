# Design system release cascade: verified walkthrough

This is the sequence that was run end to end (Oct 31, 2026) on local copies of both repos. Bare
git remotes stood in for GitHub, and scripts did what the workflows do. Commit history in both
repos records it.

| # | Design system PR title | Gate | Release | Site impact | Site checks | Visual diff vs main | Outcome |
|---|---|---|---|---|---|---|---|
| 0 | `docs: tidy foundation comments` (changed `--color-border`) | **✗ blocked**: needs patch, declares none | – | – | – | – | Retitled |
| 1 | `fix: stronger borders on cards, dividers and the header` | ✓ patch | **1.0.1** | 1 changed value the site uses | lint ✓ ds:check ✓ smoke 24/24 ✓ | 0.06–0.35% per page (border lines only) under the 0.5% patch gate | Auto-mergeable, merged |
| 2 | `feat: add --color-positive, --color-negative and the star icon` | ✓ minor | **1.1.0** | 3 added, nothing used yet | all ✓ | 0.000% everywhere | Merged |
| 3a | `feat: clearer name for the subdued text color` (renamed a variable) | **✗ blocked**: needs major, declares minor | – | – | – | – | Retitled |
| 3b | `feat!: rename --color-subdued to --color-text-subdued` | ✓ major | **2.0.0** | **Removed and used by this site: `--color-subdued`** | **ds:check ✗** names footer, card, tokens CSS; smoke still passed (an unset var fails silently, which is why ds:check exists) | – | Developer fixed 3 CSS files on the PR branch |
| 3c | (follow-up commit on `ds-v2-0-0`) | – | – | – | ds:check ✓ smoke 24/24 ✓ unit 141/141 ✓ | 0.004% (the token name label on /design-system) | Merged by a human |

Smoke = 6 pages × light/dark × 1280/390 px: no console errors, no failed requests, no axe WCAG 2 A/AA
violations.

Takeaways:
- Semver comes from the API diff, not from memory, and a wrong PR title is caught before release.
- The site sees exactly what a release touches before merging, and a breaking change cannot merge
  green.
- Patch releases that look like patches (tiny visual change) can merge themselves. One that moves
  more than 0.5% of a page fails the gate and waits for a person.
