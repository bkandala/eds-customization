# 7. The design system is a separate, pinned, vendored package

Date: 2026-10-31

## Status

Accepted

## Context

The design system (Spectrum 2 tokens, foundation CSS, fonts, icons) changes on its own schedule
and could serve several sites. Sites need to choose when to take a change and to test it first.
Edge Delivery serves code straight from the git repo, with no build step, and every stylesheet
in `head.html` blocks first paint.

Options considered:

1. **Runtime load from a versioned URL** (another EDS site or a CDN). This adds a cross-origin,
   render-blocking request on every page. A bad release, or an outage of that origin, breaks every
   site at once, and pinning depends on URL discipline.
2. **Copy-paste into each site.** No version, no changelog, and drift is invisible.
3. **Separate repo, semver tags, pinned in `package.json`, vendored into the site's git.**

## Decision

Option 3. The design system repo releases with release-please and Conventional Commits. An API diff
gate in its CI matches the declared bump to the change. Each site pins an exact tag. `npm run
ds:update` copies `dist/` into `styles/ds/` and `img/icons/`, and records the version in
`styles/ds/ds.json`. A release notifies consumers, and each consumer opens a PR that runs that
site's own tests, smoke and accessibility checks, and a visual diff.

## Consequences

- The site serves design system files from its own origin: no extra latency, and no shared runtime
  point of failure.
- Updating is a reviewed commit with a preview URL, and rolling back is a revert.
- `styles/ds/` must never be edited by hand. `ds:check` fails CI if it differs from the pinned version.
- Design system icons share `img/icons/` with site icons, because Author Kit resolves `:name:`
  there. A clash fails `ds:sync`.
- CI needs read access to the design system repo (`DS_READ_TOKEN`).
