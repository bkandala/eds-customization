#!/usr/bin/env node
/* Visual diff of every page between two running sites, usually main vs a design system update.
 *
 *   npm run test:visual -- --base http://localhost:3001 --head http://localhost:3000
 *   ... --threshold 0.5     fail if a page changes more than 0.5% of its pixels
 *                           (default: report only)
 *
 * Writes visual-report/: base, head and diff PNGs per page, plus report.md (also appended to
 * $GITHUB_STEP_SUMMARY). A design system patch should move few pixels; a minor may add some;
 * anything unexpected is visible here before merge.
 */
import { appendFileSync, mkdirSync, rmSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { chromium } from 'playwright';
import pixelmatch from 'pixelmatch';
import { PNG } from 'pngjs';
import { pages, root } from '../support/pages.mjs';

const arg = (name, fallback) => {
  const i = process.argv.indexOf(`--${name}`);
  return i > 0 ? process.argv[i + 1] : fallback;
};
const base = arg('base');
const head = arg('head');
const threshold = arg('threshold') ? Number(arg('threshold')) : null;
if (!base || !head) {
  console.error('Usage: compare.mjs --base <url> --head <url> [--threshold <percent>]');
  process.exit(1);
}
const out = join(root, 'visual-report');
rmSync(out, { recursive: true, force: true });
mkdirSync(out, { recursive: true });

const browser = await chromium.launch();
async function shot(ctx, url) {
  const page = await ctx.newPage();
  await page.goto(url, { waitUntil: 'networkidle' });
  await page.waitForTimeout(500);
  const buf = await page.screenshot({ fullPage: true, animations: 'disabled' });
  await page.close();
  return PNG.sync.read(buf);
}

// Pad both images to the same size so height changes show up as differences, not crashes.
function pad(img, width, height) {
  if (img.width === width && img.height === height) return img;
  const padded = new PNG({ width, height });
  padded.data.fill(255);
  PNG.bitblt(img, padded, 0, 0, img.width, img.height, 0, 0);
  return padded;
}

const rows = [];
let worst = 0;
for (const colorScheme of ['light', 'dark']) {
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 }, colorScheme });
  for (const path of pages()) {
    const name = `${(path === '/' ? 'home' : path.slice(1).replace(/\//g, '_'))}-${colorScheme}`;
    const a = await shot(ctx, base + path);
    const b = await shot(ctx, head + path);
    const width = Math.max(a.width, b.width);
    const height = Math.max(a.height, b.height);
    const [pa, pb] = [pad(a, width, height), pad(b, width, height)];
    const diff = new PNG({ width, height });
    const changed = pixelmatch(pa.data, pb.data, diff.data, width, height, { threshold: 0.02 });
    const pct = (changed / (width * height)) * 100;
    worst = Math.max(worst, pct);
    if (changed) {
      writeFileSync(join(out, `${name}-base.png`), PNG.sync.write(pa));
      writeFileSync(join(out, `${name}-head.png`), PNG.sync.write(pb));
      writeFileSync(join(out, `${name}-diff.png`), PNG.sync.write(diff));
    }
    rows.push(`| ${path} | ${colorScheme} | ${pct.toFixed(3)}% | ${a.height === b.height ? '' : `${a.height} → ${b.height}px`} |`);
    console.log(`${changed ? '△' : '='} ${path.padEnd(16)} ${colorScheme.padEnd(5)} ${pct.toFixed(3)}% changed`);
  }
  await ctx.close();
}
await browser.close();

const md = `### Visual diff
Base: ${base}  \nHead: ${head}

| Page | Scheme | Pixels changed | Height |
|---|---|---|---|
${rows.join('\n')}

Largest change: **${worst.toFixed(2)}%**. Diff images are in the \`visual-report\` artifact.
`;
writeFileSync(join(out, 'report.md'), md);
if (process.env.GITHUB_STEP_SUMMARY) appendFileSync(process.env.GITHUB_STEP_SUMMARY, md);
if (threshold !== null && worst > threshold) {
  console.error(`A page changed ${worst.toFixed(2)}%, over the ${threshold}% threshold.`);
  process.exit(1);
}
