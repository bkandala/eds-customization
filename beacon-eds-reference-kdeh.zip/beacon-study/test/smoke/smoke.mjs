#!/usr/bin/env node
/* Loads every page in content/ in a real browser, light and dark, desktop and mobile, and fails on
 * console errors, failed requests, or WCAG 2 A/AA violations (axe-core). This is the check that
 * tells you a design system release still works on this site.
 *
 *   npm run test:smoke                         starts the dev server itself
 *   npm run test:smoke -- --url https://<branch>--beacon-study--<org>.aem.page
 *     (against a branch preview)
 */
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { chromium } from 'playwright';
import { pages, startServer } from '../support/pages.mjs';

const require = createRequire(import.meta.url);
const axeSource = readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8');
const urlArg = process.argv.indexOf('--url');
const server = urlArg > 0
  ? { url: process.argv[urlArg + 1], stop: () => {} }
  : await startServer(3100);
const browser = await chromium.launch();
let failures = 0;

for (const colorScheme of ['light', 'dark']) {
  for (const width of [1280, 390]) {
    const ctx = await browser.newContext({ viewport: { width, height: 900 }, colorScheme });
    for (const path of pages()) {
      const page = await ctx.newPage();
      const problems = [];
      page.on('console', (m) => { if (m.type() === 'error') problems.push(`console: ${m.text()}`); });
      page.on('pageerror', (e) => problems.push(`error: ${e.message}`));
      page.on('response', (r) => { if (r.status() >= 400) problems.push(`${r.status()}: ${r.url()}`); });
      await page.goto(server.url + path, { waitUntil: 'networkidle' });
      await page.waitForTimeout(400);
      await page.evaluate(axeSource);
      const violations = await page.evaluate(async () => (await window.axe.run(document, { runOnly: ['wcag2a', 'wcag2aa'] })).violations);
      for (const v of violations) problems.push(`a11y ${v.id}: ${v.nodes.map((n) => n.target.join(' ')).slice(0, 3).join(', ')}`);
      const label = `${colorScheme.padEnd(5)} ${String(width).padStart(4)} ${path}`;
      if (problems.length) {
        failures += 1;
        console.log(`✗ ${label}\n    ${problems.join('\n    ')}`);
      } else console.log(`✓ ${label}`);
      await page.close();
    }
    await ctx.close();
  }
}
await browser.close();
server.stop();
if (failures) {
  console.error(`\n${failures} page checks failed`);
  process.exit(1);
}
