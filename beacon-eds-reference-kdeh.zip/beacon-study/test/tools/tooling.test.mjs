// Node tests for the token build and the local content pipeline: node --test test/tools
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { render } from '../../dev/pipeline.mjs';

test('vendored design system matches the pinned version and covers every name the site uses', () => {
  execFileSync('node', ['dev/ds.mjs', 'check'], { stdio: 'pipe' });
});

test('pipeline turns da.live markup into what Author Kit expects', () => {
  const dir = mkdtempSync(join(tmpdir(), 'beacon-'));
  const file = join(dir, 'page.html');
  writeFileSync(file, `<body><main>
    <div><h1>Hello world</h1><p>:heart: <img src="/media/a.jpg" alt="A"></p>
      <div class="section-metadata"><div><div><p>Style</p></div><div><p>Center, Container</p></div></div>
      <div><div><p>Background</p></div><div><p>color-token-indigo-100</p></div></div></div></div>
    <div><div class="metadata"><div><div><p>Description</p></div><div><p>Desc</p></div></div></div></div>
  </main></body>`);
  const { page, plain } = render(file, '<!-- head -->');
  assert.match(plain, /<div data-background="color-token-indigo-100" class="center container">|<div class="center container" data-background="color-token-indigo-100">/);
  assert.match(plain, /<h1 id="hello-world">/);
  assert.match(plain, /<span class="icon icon-heart"><\/span>/);
  assert.match(plain, /<picture><source media="\(min-width: 600px\)"/);
  assert.doesNotMatch(plain, /section-metadata|class="metadata"/);
  assert.match(page, /<title>Hello world<\/title>/);
  assert.match(page, /<meta name="description" content="Desc">/);
});
