// Shared helpers for the browser checks: which pages exist, and a dev server to run them on.
import { spawn } from 'node:child_process';
import { readdirSync } from 'node:fs';
import { dirname, join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

export const root = resolve(dirname(fileURLToPath(import.meta.url)), '../..');

export function pages(dir = join(root, 'content')) {
  const out = [];
  const walk = (d) => readdirSync(d, { withFileTypes: true }).forEach((e) => {
    const p = join(d, e.name);
    if (e.isDirectory() && e.name !== 'fragments' && e.name !== 'media') walk(p);
    else if (e.name.endsWith('.html')) {
      const path = `/${relative(dir, p).replace(/\.html$/, '').replace(/(^|\/)index$/, '')}`;
      out.push(path.replace(/\/$/, '') || '/');
    }
  });
  walk(dir);
  return out.sort();
}

export async function startServer(port, cwd = root) {
  const child = spawn('node', ['dev/server.mjs'], { cwd, env: { ...process.env, PORT: String(port) }, stdio: 'pipe' });
  await new Promise((res, rej) => {
    child.stdout.on('data', (d) => { if (String(d).includes('http://')) res(); });
    child.on('exit', (code) => rej(Error(`dev server exited ${code}`)));
  });
  return { url: `http://localhost:${port}`, stop: () => child.kill() };
}
