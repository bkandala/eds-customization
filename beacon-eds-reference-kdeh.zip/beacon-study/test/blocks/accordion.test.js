import { expect } from '@esm-bundle/chai';
import init from '../../blocks/accordion/accordion.js';

function mount(variants = '') {
  const el = document.createElement('div');
  el.className = `accordion ${variants}`.trim();
  el.innerHTML = `
    <div><div><p>Why was I invited?</p></div><div><p>At random.</p></div></div>
    <div><div><p>Will I be paid?</p></div><div><p>Yes.</p><p>Gift cards.</p></div></div>`;
  document.body.append(el);
  init(el);
  return el;
}

afterEach(() => document.querySelectorAll('.accordion').forEach((el) => el.remove()));

describe('accordion', () => {
  it('turns each row into a closed details/summary pair', () => {
    const el = mount();
    const items = el.querySelectorAll(':scope > details.accordion-item');
    expect(items.length).to.equal(2);
    expect(items[0].open).to.be.false;
    expect(items[0].querySelector('summary').textContent).to.equal('Why was I invited?');
    expect(items[1].querySelectorAll('.accordion-body p').length).to.equal(2);
  });

  it('exclusive items share a name so only one stays open', () => {
    const el = mount('exclusive');
    const [a, b] = el.querySelectorAll('details');
    expect(a.name).to.equal(b.name).and.not.equal('');
  });

  it('first-open opens the first item', () => {
    const el = mount('first-open');
    expect(el.querySelector('details').open).to.be.true;
  });
});
