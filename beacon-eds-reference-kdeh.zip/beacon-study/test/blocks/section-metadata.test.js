import { expect } from '@esm-bundle/chai';
import { getColorScheme } from '../../blocks/section-metadata/section-metadata.js';

function scheme(color) {
  const el = document.createElement('div');
  el.style.backgroundColor = color;
  document.body.append(el);
  const result = getColorScheme(el);
  el.remove();
  return result;
}

describe('section color scheme', () => {
  it('uses dark text on light backgrounds and light text on dark ones', () => {
    expect(scheme('rgb(255, 255, 255)')).to.equal('light-scheme');
    expect(scheme('rgb(17, 17, 17)')).to.equal('dark-scheme');
  });

  it('picks dark text on mid-light colors where white would fail contrast', () => {
    // Spectrum indigo-1000 in dark mode: white text is 2.6:1, black is 8:1
    expect(scheme('rgb(139, 141, 254)')).to.equal('light-scheme');
  });
});
