import { expect } from '@esm-bundle/chai';
import init from '../../blocks/card/card.js';

const PIC = '<p><picture><img src="data:," alt=""></picture></p>';

function mount(inner) {
  const el = document.createElement('div');
  el.className = 'card';
  el.innerHTML = `<div>${inner}</div>`;
  document.body.append(el);
  init(el);
  return el;
}

afterEach(() => document.querySelectorAll('.card').forEach((el) => el.remove()));

describe('card', () => {
  it('handles image and text in one cell', () => {
    const el = mount(`<div>${PIC}<h3>Name</h3><p>Role</p></div>`);
    expect(el.querySelector('.card-content-container h3')).to.exist;
  });

  it('handles image and text in separate cells', () => {
    const el = mount(`<div>${PIC}</div><div><h3>Name</h3><p>Role</p></div>`);
    const inner = el.querySelector('.card-inner');
    expect(inner.children.length).to.equal(2);
    expect(el.querySelector('.card-content-container h3')).to.exist;
  });
});
