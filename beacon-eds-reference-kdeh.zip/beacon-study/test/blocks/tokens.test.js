import { expect } from '@esm-bundle/chai';
import init from '../../blocks/tokens/tokens.js';

const nextFrame = () => new Promise((r) => { requestAnimationFrame(() => setTimeout(r)); });

describe('tokens block', () => {
  before(() => document.documentElement.style.setProperty('--test-red', 'rgb(255, 0, 0)'));

  it('renders a swatch per token and shows the resolved value', async () => {
    const el = document.createElement('div');
    el.className = 'tokens colors';
    el.innerHTML = '<div><div><p>Test</p></div><div><p>test-red, --test-red</p></div></div>';
    document.body.append(el);
    init(el);
    await nextFrame();
    const tokens = el.querySelectorAll('.token');
    expect(tokens.length).to.equal(2);
    expect(tokens[0].querySelector('code').textContent).to.equal('--test-red');
    expect(tokens[0].querySelector('.token-value').textContent).to.equal('rgb(255, 0, 0)');
    el.remove();
  });
});
