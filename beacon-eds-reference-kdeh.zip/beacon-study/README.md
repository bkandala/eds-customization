# BEACON Study: EDS reference implementation

A fresh Adobe Edge Delivery Services (EDS) site built on **[Author Kit](https://github.com/aemsites/author-kit)**
(da.live authoring). It uses the **BEACON Design System**, which is built on Adobe Spectrum 2, lives
in a separate repo and is pinned by version. The sample site is a fictional research-study website
with Home, About, Research Team, FAQ, Newsletter and a live Design System page. BEACON and the
Northwind Health Research Institute are fictional.

```
beacon-design-system  ── vX.Y.Z tag ──▶  beacon-study (this repo)
Spectrum 2 tokens, foundation CSS,        Author Kit engine + blocks + content
fonts, icons; semver releases             pins @beacon/design-system, vendors it into styles/ds/
```

## Quick start (no accounts, no network)

Keep the two repos side by side. Until you push them to GitHub, the site resolves the design
system from `../beacon-design-system`.

```
work/
  beacon-design-system/
  beacon-study/        ← you are here
```

```bash
npm ci
npm run dev          # http://localhost:3000, renders content/ like Edge Delivery
```

`content/*.html` are documents in da.live's format. `dev/pipeline.mjs` does what the Edge Delivery
pipeline does for them: it turns section metadata into classes and data attributes, metadata into
`<meta>`, `:icon:` into icon spans and `<img>` into `<picture>`. Edit a document or a block and
reload.

## How it fits together

```
head.html
  /styles/ds/tokens.css        design system: Spectrum 2 --s2-* tokens        (vendored, do not edit)
  /styles/ds/foundation.css    design system: --color-*, type, buttons, fonts  (vendored, do not edit)
  /styles/styles.css           site: layout, sections, Author Kit plumbing
  /scripts/scripts.js          site config → scripts/ak.js (Author Kit engine; do not edit)
blocks/<name>/<name>.{js,css}  site blocks; use DS variables, never raw colors
img/icons/                     site icons + design system icons (listed in styles/ds/ds.json)
content/                       sample pages in da.live format (+ media/)
```

### Blocks

| Block | Variants | Used for |
|---|---|---|
| `hero` | `large`, `small`, `center`, `light`, `stack` | Home banner; page title banners |
| `columns` | `stats`, `gap-xxl`, `z-pattern`, `image-cover`, `align-top` | Image + text; big-number band |
| `card` | `feature` (icon badge), `profile` (round photo), `quiet`, `center` | Activities, team, newsletters, contact |
| `accordion` (new) | `exclusive`, `first-open`, `quiet` | FAQ |
| `tokens` (new) | `colors`, `type`, `spacing`, `radius` | Live token specimens on /design-system |
| `header`, `footer`, `fragment`, `section-metadata` | from Author Kit | Nav, footer, contact fragment, section layout |

Authoring is the Author Kit convention: a block is a table whose first row is the block name, with
variants in brackets, e.g. `Card (feature)`. Buttons are formatted links: **bold** for primary,
*italic* for secondary, ***both*** for accent, ~~strikethrough~~ for negative, underline for outline.
Section metadata sets `grid`, `gap`, `spacing`, `container`, `background` (`color-token-indigo-100`)
and `style`.

## The design system dependency

The design system is pinned in `package.json` (`@beacon/design-system`) and **vendored**: Edge
Delivery serves files straight from git, so the exact CSS, fonts and icons the site runs are
committed.

```bash
npm run ds:update -- 2.1.0         # install that tag from GitHub, vendor it, print the impact report
npm run ds:update:local -- 2.1.0   # same, from the tag in ../beacon-design-system (offline)
npm run ds:check             # vendored files match the pin; every DS name the site uses exists
npm run ds:impact            # what changed vs the last commit, and what this site touches
```

**Cascade.** When the design system releases, its workflow notifies this repo. Here,
`.github/workflows/ds-update.yml` then:

1. creates branch `ds-vX-Y-Z` and runs `ds:update`; the branch is previewable at
   `https://ds-vX-Y-Z--beacon-study--kdeh-kp.aem.page`,
2. opens a PR labelled `semver:<bump>` with the impact report (which removed names this site uses),
3. runs CI on the PR: lint, `ds:check`, unit tests (web-test-runner), the **smoke suite** (every page,
   light/dark, desktop/mobile, console errors, failed requests, axe WCAG 2 AA) and a **visual diff**
   against `main` (gated at 0.5% of pixels on patch releases),
4. auto-merges patch releases when CI is green; minor and major wait for review. Set this with the
   `DS_AUTOMERGE` variable: `patch` (default), `minor` or `none`.

Run the checks yourself:

```bash
npm run lint && npm run ds:check && npm run test:tools && npm test
npm run test:smoke
PORT=3001 npm run dev   # in a checkout of main
npm run test:visual -- --base http://localhost:3001 --head http://localhost:3000
```

## Going live

1. **Repos.** Create `KDEH-KP/beacon-design-system` and `KDEH-KP/beacon-study` and push both,
   with tags. `package.json` (`config.dsSource`) and the design system's `consumers.json` already
   point at `KDEH-KP`.
2. **Pin from GitHub.** In this repo run `npm run ds:update -- 2.0.0` once. That moves the
   dependency from `file:../beacon-design-system` to your GitHub tag and rewrites
   `package-lock.json`. Commit.
3. **Secrets.** `DS_READ_TOKEN` (read access to the design system repo, for `npm ci`) and
   `DS_BOT_TOKEN` (PAT or GitHub App token with contents and pull-request write, so the PRs it opens
   trigger CI). Allow Actions to create PRs.
4. **Edge Delivery.** Install [AEM Code Sync](https://github.com/apps/aem-code-sync) on this repo
   (on GitHub Enterprise Cloud use Cloud Manager Bring Your Own Git instead).
5. **Content.** Go to [da.live/start](https://da.live/start) and create the site for
   `KDEH-KP/beacon-study`. Upload `content/media/` to `/media`, then each document in `content/`
   (including `fragments/`) to the same path. Preview and publish.
6. **Hostnames.** Set your production domain in `scripts/scripts.js`.
7. Develop against live content with `aem up` (the AEM CLI).

## Ideas to experiment with

- **Rebrand:** in the design system set `brand.accent` to `"seafoam"`, `npm run build`, release as
  `fix:` and watch the patch visual gate stop the auto-merge (it changes too many pixels). Re-release
  it as `feat!:`.
- **Breaking rename:** remove a variable in the design system. `ds:check` names every block that
  used it.
- **New block:** add `blocks/quote/` using only `--color-*` and `--spacing-*`. Dark mode works with
  no extra code.
- **Section themes:** set `background` to any `color-token-<hue>-<100–900>`. Author Kit picks the
  text scheme with the most contrast.

Author Kit internals: [AGENTS.md](AGENTS.md) and [docs/adr/](docs/adr/). Design decisions for this
project: [docs/adr/0007](docs/adr/0007-design-system-as-a-pinned-vendored-package.md). The run that
proved the release cascade: [docs/ds-cascade-walkthrough.md](docs/ds-cascade-walkthrough.md).
