#!/usr/bin/env node
/* Consume the BEACON design system at a pinned version.
 *
 * Edge Delivery serves files straight from git, so the design system is vendored: `sync` copies
 * the installed package's dist/ into the repo, and the commit records exactly what the site
 * runs. package.json pins the version; styles/ds/ds.json records it next to the files.
 *
 *   npm run ds:update -- 1.2.0     install v1.2.0, sync, print the impact report
 *   npm run ds:sync                copy node_modules/@beacon/design-system/dist into the repo
 *   npm run ds:check               CI: vendored files match the pinned version, and every
 *                                  design system name the site uses still exists
 *   npm run ds:impact -- [old.json] what changed vs the last vendored api.json, and which of
 *                                  those changes the site's CSS and content actually touch
 *
 * Where it lands
 *   styles/ds/tokens.css, foundation.css, fonts/   (linked from head.html)
 *   img/icons/<name>.svg                           (Author Kit resolves :name: here)
 *   styles/ds/api.json, ds.json                    (tooling only, .hlxignore'd)
 *
 * Source: package.json "config.dsSource" (github:<org>/beacon-design-system), or DS_SOURCE.
 */
import {
  appendFileSync, cpSync, existsSync, mkdirSync, readFileSync, readdirSync, rmSync, writeFileSync,
} from 'node:fs';
import { execFileSync } from 'node:child_process';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const PKG = '@beacon/design-system';
const pkgDir = join(root, 'node_modules', PKG);
const vendor = join(root, 'styles/ds');
const icons = join(root, 'img/icons');
const CSS = ['tokens.css', 'foundation.css'];

const readJson = (p) => JSON.parse(readFileSync(p, 'utf8'));
const lockFile = () => (existsSync(join(vendor, 'ds.json')) ? readJson(join(vendor, 'ds.json')) : null);

function installed() {
  if (!existsSync(join(pkgDir, 'package.json'))) throw Error(`${PKG} is not installed. Run npm ci.`);
  return readJson(join(pkgDir, 'package.json')).version;
}

function sync() {
  const version = installed();
  const dist = join(pkgDir, 'dist');
  const previous = lockFile();
  rmSync(vendor, { recursive: true, force: true });
  mkdirSync(vendor, { recursive: true });
  for (const f of [...CSS, 'api.json']) cpSync(join(dist, f), join(vendor, f));
  cpSync(join(dist, 'fonts'), join(vendor, 'fonts'), { recursive: true });

  // Icons share img/icons with site-owned icons, so remove only what the last version put there.
  for (const name of previous?.icons || []) rmSync(join(icons, `${name}.svg`), { force: true });
  const names = readdirSync(join(dist, 'icons')).filter((f) => f.endsWith('.svg')).map((f) => f.slice(0, -4));
  for (const name of names) {
    if (existsSync(join(icons, `${name}.svg`))) throw Error(`img/icons/${name}.svg is site-owned and clashes with a design system icon`);
    cpSync(join(dist, 'icons', `${name}.svg`), join(icons, `${name}.svg`));
  }
  writeFileSync(join(vendor, 'ds.json'), `${JSON.stringify({
    $comment: 'Written by npm run ds:sync. Do not edit.', package: PKG, version, icons: names.sort(),
  }, null, 2)}\n`);
  console.log(`Synced ${PKG}@${version}${previous ? ` (was ${previous.version})` : ''}`);
  return { version, previous: previous?.version };
}

// Names the site depends on: var(--x) in site CSS, .btn-* via content, :icon: in content.
function siteUsage() {
  const files = [join(root, 'styles/styles.css')];
  for (const d of readdirSync(join(root, 'blocks'))) {
    const f = join(root, 'blocks', d, `${d}.css`);
    if (existsSync(f)) files.push(f);
  }
  const css = files.map((f) => readFileSync(f, 'utf8')).join('\n');
  const vars = new Set([...css.matchAll(/var\((--[a-z0-9-]+)/g)].map((m) => m[1]));
  const local = new Set([...css.matchAll(/(--[a-z0-9-]+)\s*:/g)].map((m) => m[1]));
  const content = [];
  const walk = (dir) => readdirSync(dir, { withFileTypes: true }).forEach((e) => {
    if (e.isDirectory()) walk(join(dir, e.name));
    else if (e.name.endsWith('.html')) content.push(readFileSync(join(dir, e.name), 'utf8'));
  });
  if (existsSync(join(root, 'content'))) walk(join(root, 'content'));
  const text = content.join('\n').replace(/<code>.*?<\/code>/g, '');
  const iconNames = new Set([...text.matchAll(/:([a-z0-9-]+):/g)].map((m) => m[1]));
  return { vars: [...vars].filter((v) => !local.has(v)), icons: [...iconNames] };
}

function missing(api) {
  const defined = new Set([...Object.keys(api.tokens), ...Object.keys(api.variables)]);
  const siteIcons = new Set(readdirSync(icons).map((f) => f.replace(/\.svg$/, '')));
  const { vars, icons: used } = siteUsage();
  // Variables set from JS (e.g. --child-count in columns.js) are not design system names.
  const js = readdirSync(join(root, 'blocks')).map((d) => {
    const f = join(root, 'blocks', d, `${d}.js`);
    return existsSync(f) ? readFileSync(f, 'utf8') : '';
  }).join('\n');
  return {
    vars: vars.filter((v) => !defined.has(v) && !js.includes(v)),
    icons: used.filter((i) => !siteIcons.has(i) && !api.icons.includes(i)),
  };
}

async function impact(oldApi, newApi) {
  // The diff rules ship with the design system, so the installed version judges its own change.
  const { diff } = await import(join(pkgDir, 'scripts/api-diff.mjs'));
  const result = diff(oldApi, newApi);
  const { vars, icons: usedIcons } = siteUsage();
  const used = new Set([...vars, ...usedIcons.map((i) => `icons: ${i}`)]);
  const touches = (line) => {
    const name = line.split(': ')[1];
    return used.has(name) || used.has(line);
  };
  const lines = [
    `### Design system impact: ${result.required} change`,
    '',
    `Removed ${result.removed.length} · Added ${result.added.length} · Changed ${result.changed.length}`,
  ];
  const brokenHere = result.removed.filter(touches);
  const changedHere = result.changed.filter(touches);
  if (brokenHere.length) lines.push('', '**Removed and used by this site (will break):**', ...brokenHere.map((l) => `- \`${l}\``));
  if (changedHere.length) lines.push('', '**Changed values this site uses directly:**', ...changedHere.slice(0, 30).map((l) => `- \`${l}\``));
  if (result.added.length) lines.push('', `<details><summary>Added (${result.added.length})</summary>\n`, ...result.added.map((l) => `- \`${l}\``), '\n</details>');
  if (!brokenHere.length) lines.push('', 'No removed name is used by this site.');
  const md = lines.join('\n');
  console.log(md);
  if (process.env.GITHUB_STEP_SUMMARY) appendFileSync(process.env.GITHUB_STEP_SUMMARY, `${md}\n`);
  return { ...result, brokenHere };
}

function check() {
  const lock = lockFile();
  if (!lock) throw Error('styles/ds/ds.json missing: run npm run ds:sync');
  const version = installed();
  const problems = [];
  if (lock.version !== version) problems.push(`vendored ${lock.version} but package.json pins ${version}: run npm run ds:sync`);
  const dist = join(pkgDir, 'dist');
  for (const f of CSS) {
    if (readFileSync(join(dist, f), 'utf8') !== readFileSync(join(vendor, f), 'utf8')) problems.push(`styles/ds/${f} differs from ${PKG}@${version}`);
  }
  for (const name of lock.icons) {
    if (readFileSync(join(dist, 'icons', `${name}.svg`), 'utf8') !== readFileSync(join(icons, `${name}.svg`), 'utf8')) problems.push(`img/icons/${name}.svg differs from ${PKG}@${version}`);
  }
  const gone = missing(readJson(join(vendor, 'api.json')));
  for (const v of gone.vars) problems.push(`site CSS uses ${v}, which ${PKG}@${version} does not define`);
  for (const i of gone.icons) problems.push(`content uses :${i}:, which is neither a site icon nor in ${PKG}@${version}`);
  if (problems.length) {
    console.error(problems.map((p) => `✗ ${p}`).join('\n'));
    process.exit(1);
  }
  console.log(`✓ ${PKG}@${version} vendored intact; every design system name the site uses exists.`);
}

const [cmd, arg] = process.argv.slice(2);
if (cmd === 'sync') sync();
else if (cmd === 'check') check();
else if (cmd === 'impact') {
  const oldApi = arg ? readJson(arg) : JSON.parse(execFileSync('git', ['show', 'HEAD:styles/ds/api.json'], { cwd: root }).toString());
  await impact(oldApi, readJson(join(vendor, 'api.json')));
} else if (cmd === 'update') {
  if (!arg) throw Error('Usage: npm run ds:update -- <version>');
  const source = process.env.DS_SOURCE || readJson(join(root, 'package.json')).config.dsSource;
  const oldApi = existsSync(join(vendor, 'api.json')) ? readJson(join(vendor, 'api.json')) : {};
  const spec = `${source}#v${arg.replace(/^v/, '')}`;
  console.log(`Installing ${PKG} from ${spec}`);
  execFileSync('npm', ['install', '--save-dev', '--save-exact', `${PKG}@${spec}`], { cwd: root, stdio: 'inherit' });
  sync();
  const result = await impact(oldApi, readJson(join(vendor, 'api.json')));
  if (process.env.GITHUB_OUTPUT) appendFileSync(process.env.GITHUB_OUTPUT, `bump=${result.required}\nbroken=${result.brokenHere.length}\n`);
} else {
  console.error('Usage: node dev/ds.mjs <sync|check|impact|update> [version]');
  process.exit(1);
}
