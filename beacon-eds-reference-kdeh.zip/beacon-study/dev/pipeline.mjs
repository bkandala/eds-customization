/* A small, local stand-in for the Edge Delivery HTML pipeline.
 *
 * content/*.html are written the way da.live stores documents: <main> holds one <div> per section,
 * blocks are <div class="name (variant)"> tables, section-metadata and metadata are blocks.
 * Edge Delivery turns that into the markup the browser code expects. This does the parts
 * Author Kit relies on, so the site can be developed with no network and no da.live account:
 *
 *   section-metadata  → `style` becomes classes, every other row a data-* attribute on the section
 *   metadata          → <meta> tags in <head>, block removed
 *   :name:            → <span class="icon icon-name"></span>
 *   <img>             → <picture> with a desktop <source>, lazy by default
 *
 * It is not the real pipeline. Once content lives in da.live, preview there (or run `aem up`).
 */
import { readFileSync } from 'node:fs';
import { parseHTML } from 'linkedom';

const toKey = (text) => text.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
const toClass = (text) => text.split(',').map(toKey).filter(Boolean);

function readRows(block) {
  return [...block.children].map((row) => {
    const [key, val] = [...row.children];
    return [toKey(key?.textContent || ''), val];
  });
}

function sectionMetadata(main) {
  for (const meta of main.querySelectorAll(':scope > div > div.section-metadata')) {
    const section = meta.parentElement;
    for (const [key, cell] of readRows(meta)) {
      const value = cell?.textContent.trim();
      if (!key || !value) continue;
      if (key === 'style') section.classList.add(...toClass(value));
      else section.dataset[key.replace(/-([a-z])/g, (_, c) => c.toUpperCase())] = value;
    }
    meta.remove();
  }
}

function pageMetadata(main) {
  const meta = {};
  const block = main.querySelector('div.metadata');
  if (!block) return meta;
  for (const [key, cell] of readRows(block)) {
    if (!key) continue;
    const link = cell.querySelector('a, img');
    meta[key] = link?.getAttribute('href') || link?.getAttribute('src') || cell.textContent.trim();
  }
  const section = block.parentElement;
  block.remove();
  if (!section.children.length) section.remove();
  return meta;
}

function icons(document, main) {
  const walker = document.createTreeWalker(main, 4 /* NodeFilter.SHOW_TEXT */);
  const nodes = [];
  while (walker.nextNode()) {
    if (/:[a-z0-9-]+:/.test(walker.currentNode.textContent) && !walker.currentNode.parentElement.closest('code, pre')) {
      nodes.push(walker.currentNode);
    }
  }
  for (const node of nodes) {
    const html = node.textContent
      .replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/:([a-z0-9-]+):/g, '<span class="icon icon-$1"></span>');
    const tpl = document.createElement('template');
    tpl.innerHTML = html;
    node.replaceWith(...tpl.content.childNodes);
  }
}

// Edge Delivery gives every heading an id from its text, which is what deep links rely on.
function headingIds(main) {
  for (const h of main.querySelectorAll('h1, h2, h3, h4, h5, h6')) {
    if (!h.id) h.id = toKey(h.textContent);
  }
}

function pictures(document, main) {
  for (const img of main.querySelectorAll('img')) {
    if (img.closest('picture')) continue;
    const src = img.getAttribute('src');
    const pic = document.createElement('picture');
    const source = document.createElement('source');
    source.setAttribute('srcset', `${src}?width=2000&format=webply&optimize=medium`);
    source.setAttribute('media', '(min-width: 600px)');
    const out = document.createElement('img');
    out.setAttribute('loading', 'lazy');
    out.setAttribute('alt', img.getAttribute('alt') || '');
    out.setAttribute('src', `${src}?width=750&format=webply&optimize=medium`);
    for (const attr of ['width', 'height', 'title']) {
      if (img.hasAttribute(attr)) out.setAttribute(attr, img.getAttribute(attr));
    }
    pic.append(source, out);
    img.replaceWith(pic);
  }
}

const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');

export function render(file, headHtml) {
  const { document } = parseHTML(readFileSync(file, 'utf8'));
  const main = document.querySelector('main');
  if (!main) throw Error(`${file} has no <main>`);
  const meta = pageMetadata(main);
  sectionMetadata(main);
  headingIds(main);
  icons(document, main);
  pictures(document, main);

  const title = meta.title || main.querySelector('h1')?.textContent.trim() || '';
  delete meta.title;
  const tags = [
    title && `<title>${esc(title)}</title>`,
    title && `<meta property="og:title" content="${esc(title)}">`,
    ...Object.entries(meta).map(([k, v]) => `<meta name="${esc(k)}" content="${esc(v)}">`),
  ].filter(Boolean).join('\n');

  const plain = main.innerHTML.trim();
  const page = `<!DOCTYPE html>
<html>
<head>
${tags}
${headHtml}
</head>
<body>
<header></header>
<main>
${plain}
</main>
<footer></footer>
</body>
</html>
`;
  return { page, plain, meta };
}
