#!/usr/bin/env node
/* Local dev server: code from the repo, content from content/ rendered by dev/pipeline.mjs.
 *
 *   npm run dev            → http://localhost:3000
 *   PORT=4000 npm run dev
 *
 * Pages render on every request, so edits to content/ or code show on reload.
 */
import { createServer } from 'node:http';
import { existsSync, readFileSync, statSync } from 'node:fs';
import { extname, join, normalize, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { render } from './pipeline.mjs';

const root = resolve(fileURLToPath(import.meta.url), '../..');
const content = join(root, 'content');
const port = Number(process.env.PORT || 3000);

const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.pdf': 'application/pdf',
  '.webmanifest': 'application/manifest+json',
  '.txt': 'text/plain; charset=utf-8',
};

const isFile = (p) => existsSync(p) && statSync(p).isFile();

function findDoc(pathname) {
  const clean = pathname.replace(/\/$/, '/index');
  for (const candidate of [`${clean}.html`, `${clean}/index.html`]) {
    const file = join(content, candidate);
    if (file.startsWith(content) && isFile(file)) return file;
  }
  return null;
}

function send(res, status, body, type) {
  res.writeHead(status, { 'content-type': type, 'cache-control': 'no-store' });
  res.end(body);
}

createServer((req, res) => {
  const { pathname } = new URL(req.url, 'http://localhost');
  const path = normalize(decodeURIComponent(pathname));
  const head = readFileSync(join(root, 'head.html'), 'utf8');
  try {
    // Operational telemetry beacons (sampled) go to /.rum on Edge Delivery; accept and drop them.
    if (path.startsWith('/.rum')) return send(res, 204, '', 'text/plain');
    // Plain HTML (what fragments and da.live preview fetch)
    if (path.endsWith('.plain.html')) {
      const doc = findDoc(path.replace(/\.plain\.html$/, ''));
      if (doc) return send(res, 200, render(doc, head).plain, TYPES['.html']);
    }
    // Static files: code first, then content (media, pdfs, json)
    if (extname(path)) {
      for (const base of [root, content]) {
        const file = join(base, path);
        if (file.startsWith(base) && isFile(file) && !file.includes(`${root}/node_modules`)) {
          return send(res, 200, readFileSync(file), TYPES[extname(file)] || 'application/octet-stream');
        }
      }
      return send(res, 404, 'Not found', 'text/plain');
    }
    // Pages
    const doc = findDoc(path);
    if (doc) return send(res, 200, render(doc, head).page, TYPES['.html']);
    const notFound = findDoc('/404');
    return send(res, 404, notFound ? render(notFound, head).page : 'Not found', TYPES['.html']);
  } catch (ex) {
    console.error(ex);
    return send(res, 500, String(ex.stack), 'text/plain');
  }
}).listen(port, () => {
  console.log(`BEACON Study dev server: http://localhost:${port}`);
});
