// Each row is one item: [question | answer]. Native <details> gives keyboard and screen reader
// support for free; `exclusive` makes the items share a name so only one stays open.
export default function init(el) {
  const exclusive = el.classList.contains('exclusive');
  const name = `accordion-${Math.random().toString(36).slice(2, 8)}`;
  const items = [...el.children].map((row) => {
    const [label, body] = row.children;
    const details = document.createElement('details');
    details.className = 'accordion-item';
    if (exclusive) details.name = name;
    const summary = document.createElement('summary');
    summary.className = 'accordion-label';
    summary.append(...label.childNodes);
    const panel = document.createElement('div');
    panel.className = 'accordion-body';
    panel.append(...(body?.childNodes || []));
    details.append(summary, panel);
    return details;
  });
  el.replaceChildren(...items);
  if (el.classList.contains('first-open') && items[0]) items[0].open = true;
}
