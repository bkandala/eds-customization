// Renders live samples of design tokens so authors and developers can see what a token resolves
// to in the current color scheme. Variant picks the sample: colors, type, spacing or radius.
// Each row: [group label | comma separated token names, with or without the leading --]
const KINDS = ['colors', 'type', 'spacing', 'radius'];

const toVar = (name) => `--${name.trim().replace(/^-+/, '')}`;

function sample(kind, prop) {
  const el = document.createElement('div');
  el.className = 'token-sample';
  if (kind === 'colors') el.style.background = `var(${prop})`;
  if (kind === 'type') {
    el.textContent = 'Heart health, studied for life';
    el.style.fontSize = `var(${prop})`;
  }
  if (kind === 'spacing') el.style.width = `var(${prop})`;
  if (kind === 'radius') el.style.borderRadius = `var(${prop})`;
  return el;
}

function resolved(kind, el, prop) {
  const style = getComputedStyle(el);
  if (kind === 'colors') return style.backgroundColor;
  if (kind === 'type') return style.fontSize;
  if (kind === 'spacing') return style.width;
  if (kind === 'radius') return style.borderTopLeftRadius;
  return getComputedStyle(document.documentElement).getPropertyValue(prop).trim();
}

export default function init(el) {
  const kind = KINDS.find((k) => el.classList.contains(k)) || 'colors';
  el.classList.add(kind);
  const tokens = [];
  const groups = [...el.children].map((row) => {
    const [label, list] = row.children;
    const group = document.createElement('section');
    group.className = 'token-group';
    const heading = document.createElement('h3');
    heading.textContent = label.textContent.trim();
    const grid = document.createElement('ul');
    grid.className = 'token-list';
    for (const name of (list?.textContent || '').split(',').filter((n) => n.trim())) {
      const prop = toVar(name);
      const li = document.createElement('li');
      li.className = 'token';
      const swatch = sample(kind, prop);
      const code = document.createElement('code');
      code.textContent = prop;
      const value = document.createElement('span');
      value.className = 'token-value';
      li.append(swatch, code, value);
      grid.append(li);
      tokens.push({ swatch, value, prop });
    }
    group.append(heading, grid);
    return group;
  });
  el.replaceChildren(...groups);

  // Values depend on layout and color scheme, so read them after paint and on scheme changes.
  const update = () => tokens.forEach(({ swatch, value, prop }) => {
    value.textContent = resolved(kind, swatch, prop);
  });
  requestAnimationFrame(update);
  new MutationObserver(update).observe(document.body, { attributes: true, attributeFilter: ['class'] });
  matchMedia('(prefers-color-scheme: dark)').addEventListener('change', update);
}
